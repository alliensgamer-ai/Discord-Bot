# Puzzles Bot — paquete de producción para Quaxly

Este ZIP es una copia standalone temporal para ejecutar Puzzles Bot en Quaxly. Replit continúa siendo el proyecto principal de desarrollo. Esta copia no depende de GitHub ni de otros artifacts del monorepo.

## Requisitos

- Node.js 20 o superior.
- Una base de datos PostgreSQL accesible desde Quaxly.
- Las variables de entorno configuradas en el panel de Quaxly.

## Variables de entorno

Configura estas variables en Quaxly. No las guardes en archivos del ZIP:

- `DISCORD_TOKEN` — obligatoria.
- `DATABASE_URL` — obligatoria y debe apuntar a la base de datos PostgreSQL existente.
- `DISCORD_CLIENT_ID` — opcional.
- `DISCORD_GUILD_ID` — opcional; útil para registrar comandos inmediatamente en un servidor de desarrollo.
- `RANKING_ADMIN_ROLE_ID` — opcional.
- `RANKING_CHANNEL_ID` — opcional.

El archivo `.env.example` solo documenta los nombres y no contiene valores.

## Instalación y ejecución

Desde la carpeta donde se descomprimió el ZIP:

```bash
npm ci
npm run build
npm start
```

El comando de producción es:

```bash
node dist/index.mjs
```

## Importante

- No ejecutes simultáneamente el workflow de desarrollo de Replit y esta copia en Quaxly usando el mismo token, porque serían dos instancias del bot.
- No ejecutes migraciones ni comandos de modificación de esquema desde este paquete. La base de datos debe ser la existente y compatible con el proyecto principal.
- El bundle incluye el código del bot y el módulo compartido `lib/db`; no incluye `node_modules`, archivos `.env` con valores reales, otros artifacts ni archivos del workspace principal.
